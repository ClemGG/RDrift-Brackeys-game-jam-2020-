using System;
using System.Collections.Generic;
using UnityEngine;

// Simple Hover Engine Array for Vektor Physics
[System.Serializable]
public class HoverArray {

	// Virtual hover engines defined by points
	public Transform[] HoverEngines;

	// Maximum combined thrust that the array can produce
	public float MaxThrust;
		
	// Desired distance from a surface that each engine will attempt to maintain
	public float HoverDistance;
		
	// Max distance that each engine will check for a surface
	public float TraceDistance;
		
	// Layer used for raycasting
	public LayerMask TraceLayer;
		
	// Force used by each engine (calculated internally)
	private float _perEngineForce;
		
	// The Rigidbody that this array will act on
	private Rigidbody _rigidbody;
		
	//Initialization
	public void Initialize(Rigidbody rigidbody) {
		_rigidbody = rigidbody;
		_perEngineForce = MaxThrust / HoverEngines.Length;
	}
		
	// Update the hover array
	public void Update() {
		// Update each engine in the array
		foreach (var engine in HoverEngines) {
			// Generate a ray for each engine and perform a ccheck
			var engineRay = new Ray(engine.position, -engine.up);
			RaycastHit rayHit;
				
			// Check if a surface exists below this engine and update it, otherwise continue
			if (!Physics.Raycast(engineRay, out rayHit, TraceDistance, TraceLayer)) continue;
				
			// Calculate the force this engine needs to produce
			// TODO: Improve the proportional calculation by replacing it with a proper PID controller implementation
			_rigidbody.AddForceAtPosition(_rigidbody.transform.up * _perEngineForce * (1f - Vector3.Distance(engine.position, rayHit.point) / HoverDistance), engine.position);
		}
	}
}
